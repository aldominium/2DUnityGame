﻿using UnityEngine;
using System.Collections;

public class StartScript : MonoBehaviour {



	void ChangeScene(){
		Debug.Log ("Mouse enter");
	}
}
